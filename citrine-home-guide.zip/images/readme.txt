Put your photos in this folder and update the IMAGES array in index.html like:
IMAGES = ["images/living.jpg","images/yard.jpg","images/bedroom.jpg"]
